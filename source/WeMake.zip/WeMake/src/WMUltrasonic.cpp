#include "WMUltrasonic.h"

WMUltrasonic::WMUltrasonic(uint8_t echoPin,uint8_t triggerPin):SR04(echoPin,triggerPin)
{
	
}